# 🚀 Quick Fix Setup Script

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Book Status & Real-Time Updates Fix  " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/3] Checking database connection..." -ForegroundColor Yellow

# Test MySQL connection
$mysqlTest = & mysql -u root -p -e "USE library_db; SELECT COUNT(*) FROM books;" 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Database connected successfully" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "[2/3] Running database migration..." -ForegroundColor Yellow
    
    # Run migration script
    & mysql -u root -p library_db -e @"
-- Add new columns
ALTER TABLE books ADD COLUMN IF NOT EXISTS total_copies INT NOT NULL DEFAULT 1;
ALTER TABLE books ADD COLUMN IF NOT EXISTS borrowed_copies INT NOT NULL DEFAULT 0;

-- Update borrowed_copies based on is_borrowed
UPDATE books 
SET borrowed_copies = CASE 
    WHEN is_borrowed = TRUE THEN 1 
    ELSE 0 
END
WHERE borrowed_copies = 0;

-- Show results
SELECT 'Migration completed!' AS status;
SELECT id, name, total_copies, borrowed_copies, is_borrowed FROM books LIMIT 5;
"@
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Database migration successful" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Migration had warnings (may be okay if columns already exist)" -ForegroundColor Yellow
    }
} else {
    Write-Host "❌ Database connection failed" -ForegroundColor Red
    Write-Host "Please ensure MySQL is running and credentials are correct" -ForegroundColor Red
    Write-Host ""
    Write-Host "Manual steps:" -ForegroundColor Yellow
    Write-Host "1. Open MySQL Workbench" -ForegroundColor White
    Write-Host "2. Connect to library_db" -ForegroundColor White
    Write-Host "3. Run the migration script from database_migration.sql" -ForegroundColor White
}

Write-Host ""
Write-Host "[3/3] Restarting application..." -ForegroundColor Yellow
Write-Host "Please restart your Spring Boot application:" -ForegroundColor White
Write-Host "  1. Stop current server (Ctrl+C)" -ForegroundColor Cyan
Write-Host "  2. Run: .\mvnw spring-boot:run" -ForegroundColor Cyan

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "           Setup Complete! 🎉          " -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Restart Spring Boot server" -ForegroundColor White
Write-Host "2. Open: http://localhost:8081/" -ForegroundColor White
Write-Host "3. Press F12 → Console to see logs" -ForegroundColor White
Write-Host "4. Watch for 'Refreshing books...' every 10 seconds" -ForegroundColor White
Write-Host ""
Write-Host "Expected Results:" -ForegroundColor Yellow
Write-Host "✅ Books show correct 'Available' or 'Borrowed' status" -ForegroundColor Green
Write-Host "✅ Status updates automatically every 10 seconds" -ForegroundColor Green
Write-Host "✅ Console shows book availability details" -ForegroundColor Green
Write-Host ""

Read-Host "Press Enter to exit"
