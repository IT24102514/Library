-- Migration script to add totalCopies and borrowedCopies columns to books table
-- Run this script if you have existing data in the books table

-- Add total_copies column with default value of 1
ALTER TABLE books ADD COLUMN IF NOT EXISTS total_copies INT NOT NULL DEFAULT 1;

-- Add borrowed_copies column with default value of 0
ALTER TABLE books ADD COLUMN IF NOT EXISTS borrowed_copies INT NOT NULL DEFAULT 0;

-- Update borrowed_copies based on existing is_borrowed flag
-- If is_borrowed is TRUE, set borrowed_copies to 1, otherwise keep it 0
UPDATE books 
SET borrowed_copies = CASE 
    WHEN is_borrowed = TRUE THEN 1 
    ELSE 0 
END
WHERE borrowed_copies = 0;

-- Optional: Update totalCopies to 3 for all books (you can customize this)
-- Uncomment the line below if you want all books to have multiple copies
-- UPDATE books SET total_copies = 3;

-- Show the results
SELECT id, name, author_name, total_copies, borrowed_copies, is_borrowed, is_deleted 
FROM books 
ORDER BY id;
